var http = require('http');
var ipaddress = '192.168.56.101';
http.createServer(function(req, res)
{
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Hello World\n');
}).listen(1337, ipaddress);

console.log('Server running at http://' + ipaddress + ':1337/');