var io = require('socket.io').listen(80);

io.configure(function () {
    io.set('transports', ['websocket', 'xhr-polling'])
});

io.socket.on('connection', function (socket) {
    socket.on('message', function () { });
    socket.on('disconnect', function () { })
});