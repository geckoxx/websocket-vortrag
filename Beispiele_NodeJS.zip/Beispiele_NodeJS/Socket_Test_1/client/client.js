var ipaddress = '192.168.56.101';
var port = '80';
var socket = io.connect('http://' + ipaddress + ':' + port + '/');

socket.on('connect', function()
{
    socket.send('connected');

    socket.on('message', function(msg)
    {
        //my msg
    });
});